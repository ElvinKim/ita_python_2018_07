
f = open("multiplication_table.txt", "w")
for x in range(2, 10):
    for y in range(1, 10):
        f.write("{} * {} = {}\n".format(x, y, x * y))
    f.write("-" * 10 + "\n")
f.close()

f = open("multiplication_table.txt", "r")

for line in f.readlines():
    print(line, end="")
    # print(line.strip())

with open("multiplication_table.txt", "a") as f:
    for x in range(10, 20):
        for y in range(1, 10):
            f.write("{} * {} = {}\n".format(x, y, x * y))
        f.write("-" * 10 + "\n")









