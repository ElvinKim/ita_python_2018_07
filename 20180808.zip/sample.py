f = open("test.txt", 'r')

f.readline()

for line in f.readlines():
    print(line)

f.close()

f = open("test_2.txt", 'w')
f.write("TEST2 from sample")
