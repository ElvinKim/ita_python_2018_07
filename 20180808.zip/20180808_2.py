"""
ITA Python - 정규표현식
"""
print("{:=^20}".format("Pattern 객체"))
import re

# match
pattern = re.compile("[a-z]+")
m = pattern.match("abc")
print(m)

m = pattern.match("ABC abc")
print(m)

# search
print("-" * 20)
pattern = re.compile("[a-z]+")
m = pattern.search("abc")
print(m)

m = pattern.search("ABC abc def")
print(m)


print("-" * 20)
pattern = re.compile("[a-z]+")
match_lst = pattern.findall("ABC abc def")
print(match_lst)

# finditer
print("-" * 20)
pattern = re.compile("[a-z]+")
match_iter = pattern.finditer("python is good!!")
print(match_iter)

for m in match_iter:
    print(m)
    print(m.group())
    print(m.start())
    print(m.end())
    print(m.span())
    print("-" * 10)

# Compile Option
print("-" * 20)
p = re.compile("abc.abc")
m = p.search("abc\nabc")
print(m)

p = re.compile("abc.abc", re.DOTALL|re.IGNORECASE)
m = p.search("abc\nABC")
print(m)

# greedy vs non-greedy
print("-" * 20)
html = """
<div>
<span>aaa</span>
<div>TEST</div>
</div>
"""

pattern = re.compile("<.*?>", re.DOTALL)
print(pattern.findall(html))

html = """
<div>
    <span>aaa</span>
    <div>TEST
        test
        teswt
        sangmook
        sangmook
    </div>
</div>
"""

pattern = re.compile("<div>.*?<div>(.*?)</div>", re.DOTALL)
print(pattern.findall(html))



for x in range(1, 12):
    for y in range(1, 10):
        print("https://python.bakyeono.net/chapter-{}-{}.html".format(x, y))