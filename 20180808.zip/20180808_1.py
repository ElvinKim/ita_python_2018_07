"""
ITA Python - 파일
"""
print("{:=^20}".format("파일 읽기"))
f = open("test_2.txt", "a")
f.write("TEST6")

with open("test3.txt", "w") as f:
    f.write("TEST!")
