f = open("test_2.txt", 'w')
f.write("TEST2 from main")

import sample

