news = '''
Washington (CNN)Special counsel Robert Mueller has offered to reduce the number of obstruction-related questions President Donald Trump would be asked by investigators, sources familiar with the negotiations tell CNN. However, Mueller wants obstruction to be addressed in person, not just in written answers.

The President's lawyers had previously offered the special counsel written answers to obstruction questions and limiting the interview to matters before his presidential inauguration, which are largely confined to collusion.
Trump's attorney, Rudy Giuliani, told reporters Wednesday that the President's legal team has received a response from Mueller's team regarding their counter-proposal for a potential interview with the President.
"We're in the process of responding to their proposal," Giuliani said after an event in Portsmouth, New Hampshire, indicating that Mueller's team had responded Tuesday.
He added that Trump has "always been interested in testifying. It's us, meaning the team of lawyers, including me, that have the most reservations about that."
Giuliani also sent a message to Mueller: It's time for the special counsel to "put up or shut up."
"They should render their report. Put up -- I mean I guess if we were playing poker (you would say) 'Put up or shut up.' What do you got?" Giuliani said. "We have every reason to believe they don't have anything of the President doing anything wrong. I don't think they have any evidence he did anything wrong."
Mueller's response, according to a source familiar with the matter, suggested adding a few more questions in writing and others as part of a potential sit-down interview.
The source relayed that though Mueller had responded, the response was an incremental development. The two sides are still negotiating, but they're only taking "baby steps," the source said.
The Trump legal team suggested several weeks ago limiting some topics to written questions and doing an interview more on collusion, as CNN has previously reported.
The special counsel appears to be open to some version of this, though the source did not explain to what extent special counsel is agreeable.
The ball is in the Trump team's court, two additional sources told CNN. Those sources would not say how long the Trump team's lawyers would take to respond.
Giuliani told CNN's "New Day" on Monday that Mueller's team had been unresponsive to their recommendations for an interview between Mueller and the President for 10 days, adding that he believed the Mueller team is "in bad faith about an interview at this point."
Giuliani also said Monday that "the odds are against" a Trump interview with Mueller, but that he "wouldn't be shocked" if the President went through with it because he "wants to do it so badly."
The Trump legal team is open to Mueller interviewing Trump with questions related to "an area of collusion, not obstruction," Giuliani said on Monday. He added that the team may be receptive to questions of obstruction "if they could show us one or two there, we can consider it. One or two questions that they really need, we'd consider it."
CNN's Steve Brusk contributed to this report.
'''


"""
구구단을 만드는 함수를 만들어 봅니다.
매개 변수를 두 개를 받습니다.
i는 몇 단 구구단을 할 것인지, j는 i단에서 몇 까지 곱하기를 할 것인지
def gugu(i, j):
구현
"""

"""
숫자 맞추기 게임
○ 1~100까지 수 중에서 하나를 랜덤하게 생성합니다
○ 이제 이 숫자를 사용자가 맞추는 게임을 만들어 봅니다
■ 사용자로 부터 숫자를 입력받습니다
■ 맞춰야 하는 숫자가 입력 받는 숫자보다 높으면 “높습니다”를 출력합니다
■ 맞춰야 하는 숫자가 입력 받는 숫자보다 높으면 “낮습니다”를 출력합니다
■ 만약 맞췄다면 “맞췄습니다”를 출력합니다.
■ 단! 숫자를 맞추기 전까지 사용자로 부터 계속 숫자를 입력 받습니다
○ 추가로 몇 번만에 맞췄는지도 출력해 봅니다
"""







