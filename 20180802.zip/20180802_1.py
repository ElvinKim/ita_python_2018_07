
lst = [x**2 for x in range(1,11)]
print(lst)

# zip
print("-" * 20)
list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
list2 = ['a', "b", "c", "d", "e"]

for x, y in zip(list1, list2):
	print(x)
	print(y)
	print("-" * 20)


white_space_lst = [" " * x for x in reversed(range(5))]
star_lst = ["*" * (2 * x + 1) for x in range(5)]

print(white_space_lst)
print(star_lst)

for w, s in zip(white_space_lst, star_lst):
	print(w + s)


# enumerate
lst = ["A", "B", "C", "D"]

index = 0
for x in lst:
	print(x, index)
	index += 1

print("-" * 20)
for index, x in enumerate(lst):
	print(x, index)

print("-" * 20)
sample_str = "ABCDEFABDEA"
s = "B"
index_lst = []

for index, c in enumerate(sample_str):
	if c == s:
		index_lst.append(index)

print(index_lst)











