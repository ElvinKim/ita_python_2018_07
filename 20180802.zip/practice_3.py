def my_average(*args):
	return sum(args) / len(args)

print(my_average(1, 2, 3, 4, 5))


def my_concat(a, *args):
	return a.join(args)

print(my_concat("*", "a", "BC", "D"))