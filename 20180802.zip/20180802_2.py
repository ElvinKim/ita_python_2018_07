"""
ITA Python - 함수
"""
print("{:=^20}".format("함수"))

def add(a, b):
	return a + b


print(add(10, 20))
print(add("ABC", "DEF"))

def odd_even(n):
	if n % 2 == 0:
		return "짝수"
	else:
		return "홀수"


print(odd_even(20))

print("{:=^20}".format("함수의 형태"))
def get_apple():
	return "apple"

print(get_apple())

def print_name(name):
	print("my name is " + name)

print(print_name("apple"))


print("{:=^20}".format("함수의 매개변수"))
print("10", 20, 30, 40, 50)

def my_sum(*args):
	total = 0

	for num in args:
		total += num

	return total

print(my_sum(1, 2, 3, 4, 5, 6, 7))

print("-" * 20)

def sample(a, b, *args):
	print(a)
	print(args)

sample(1, 2, 3, 4, 5)

print("{:=^20}".format("함수의 반환값"))
def sum_sub(a, b):
	return a + b, a - b

print(sum_sub(1, 2))


def sample():
	print("AAA")
	return 1 
	print("BBB")

sample()

print("{:=^20}".format("함수의 초깃값 설정"))
def add(a, b=20):
	return a + b

print(add(10))
print(add(20, 30))

print("{:=^20}".format("함수의 효력 범위"))

n = 1
print("before function, n : ", n)


def make_ten():
	global n
	n = 10
	print("make_ten function : ", n)

make_ten()

print("after function, n : ", n)





