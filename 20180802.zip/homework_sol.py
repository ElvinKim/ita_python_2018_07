# Problem 1-1
for i in range(5):
	print("*" * (i + 1))
 

# Problem 1-2
star_lst = ["*", "**", "***", "****", "*****"]
for x in star_lst:
	print(x)


# Problem 1-3
print("-" * 20)
for i in range(5):
	for _ in range(i + 1):
		print("*", end="")
	print("")
print("")


# Problem 2-1
print("-" * 20)
for i in range(5):
	print("{:^9}".format("*" * (2 * i + 1)))



# Problem 2-2
print("-" * 20)
for i in range(5):
	for _ in range(5 - (i + 1)):
		print(" ", end="")
	for _ in range(2 * i + 1):
		print("*", end="")
	print("")

# 참고
n = 10
for i in range(n):
    form = "{:^" + str(2 * n - 1) + "}"
    print(form.format("*" * (2 * i + 1)))

# Problem 3-1
print("-" * 20)
sample_str = "ABCDEFABDEA"
s = "B"
index_lst = []
index = 0

for c in sample_str:
	print(c, index)
	if c == s:
		index_lst.append(index)
	index += 1
print(index_lst)  # [1, 7]


# Problem 3-2
sample_str = "ABCDEFABDEA"
s = "B"
index_lst = []
index = 0

str_lst = list(sample_str)
print(str_lst)
while str_lst.count(s) != 0:
	index_lst.append(str_lst.index(s))
	str_lst[str_lst.index(s)] = 0
	print(str_lst)
print(index_lst)










