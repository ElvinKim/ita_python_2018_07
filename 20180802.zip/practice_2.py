def return_my_name():
    return "sangmook"


def repeat_my_name(n):
    for _ in range(n):
        print("sangmook")


repeat_my_name(10)
