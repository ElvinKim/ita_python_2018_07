def average(a, b):
	return (a + b) / 2


def list_average_ver1(lst):
	total = 0
	cnt = 0

	for n in lst:
		total += n
		cnt += 1
	return total / cnt

def list_average_ver2(lst):
	return sum(lst) / len(lst)

print(list_average_ver1([1, 2, 3, 4, 5]))
print(list_average_ver2([1, 2, 3, 4, 5]))

