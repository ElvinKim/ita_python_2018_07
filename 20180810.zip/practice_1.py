from openpyxl import load_workbook

wb = load_workbook("words.xlsx")
word_sheet = wb["words"]
problem1_sheet = wb.create_sheet("problem 1")

for i, row in enumerate(word_sheet.iter_rows()):
    problem1_sheet.cell(row=i+1, column=1, value=row[0].value)

wb.save("sample.xlsx")