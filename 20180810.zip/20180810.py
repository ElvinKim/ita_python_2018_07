from openpyxl import Workbook

wb = Workbook()

ws = wb.active
ws1 = wb.create_sheet("sheet1")
ws2 = wb.create_sheet("sheet2")


ws["A1"] = 10
ws.cell(row=2, column=1, value=20)

print(ws["A1"])
print(ws["A1"].value)


for x in range(1, 11):
    for y in range(1, 11):
        ws.cell(row=x, column=y, value=(x - 1) * 10 + y)

print("-" * 20)
for col_c in ws["C"]:
    print(col_c.value)

print("-" * 20)
print(ws["A:C"])
for col in ws["A:C"]:
    for cell in col:
        print(cell.value)
    print("-" * 20)

print("-" * 20)
for row_2 in ws[2]:
    print(row_2.value)

print(ws[1:3])
print("-" * 20)

for row in ws.iter_rows(min_row=2):
    print(row[1].value, row[3].value)
    print("-" * 10)

# wb.save("test.xlsx")

