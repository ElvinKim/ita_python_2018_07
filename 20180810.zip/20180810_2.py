from openpyxl import load_workbook

wb = load_workbook("test.xlsx")
# ws = wb.get_sheet_by_name("Sheet")
ws = wb["Sheet"]

print(ws["A1"].value)
ws["A1"] = 1000
print(ws["A1"].value)

wb.save("test.xlsx")