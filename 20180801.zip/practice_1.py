num1 = int(input("Insert num1: "))
num2 = int(input("Insert num2: "))

if num1 > num2:
    print("num1이 num2 보다 큽니다.")
elif num1 < num2:
    print("num2이 num1 보다 큽니다.")
else:
    print("같습니다.")
