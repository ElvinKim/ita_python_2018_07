"""
ITA Python - 제어문
"""
print("{:=^20}".format("if문"))

# if
if 1 < 2:
    print("a")
    print("b")

    if 1 > 3:
        print("c")
        print("d")
    print("e")

# if - else
print("-" * 20)
num = 10

if num % 2 == 1:
    print("짝수")
else:
    print("홀수")


# if - elif - else
print("-" * 20)
num = -1
if num > 0:
    print("양수")
elif num < 0:
    print("음수")
else:
    print("zero")

num = 12

if 12 % 2 == 0:
    print("2로 나눠진다!!!!!")
elif 12 % 3 == 0:
    print("3로 나눠진다!!!!!")
elif 12 % 4 == 0:
    print("4로 나눠진다!!!!!")

# in 조건문
print("-" * 20)
print("A" in ["A", "B", "C", "D"])
print("E" not in ["A", "B", "C", "D"])
print("python" in "python is ver good")

print("-" * 20)
if 0:
    print("TEST")

if []:
    print("TEST2")

if not None:
    print("TEST3")


print("{:=^20}".format("while 문"))

i = 0
while i < 10:
    print(i)
    i += 1  # i = i + 1

# break
x = 0
while True:
    if 3 * x > 56:
        break
    x += 1
print("x =", x)

while 3 * x < 56:
    x += 1
print("x =", x)

# continue
print("-" * 20)
a = 0
while a <= 20:
    a += 1
    if a % 2 == 0:
        continue
    print(a)

print("{:=^20}".format("for 문"))
for x in [1, 2, 3, "python"]:
    print(x)

print("-" * 20)
for i in range(10):
    print(i)

print("-" * 20)
for num in range(1,11):
    print(num ** 2)

print("-" * 20)
for c in "ABCDEFG":
    print(c)

# gugu
for i in range(2, 10):
    for j in range(1, 10):
        print("{} * {} = {}".format(i, j, i * j))
    print("-" * 10)

