"""
ITA Python - 자료형(2)
"""
print("{:=^20}".format("딕셔너리"))

d = {"name": "김상묵", "age": 30}
print(d["age"])

# 요소 추가 & 삭제
print("-" * 20)
d["id"] = 200
print(d)
del d["age"]
print(d)


# 관련된 함수
print("-" * 20)
d["age"] = 20
print(d)

# keys
print(d.keys())

# values
print(d.values())

# items
print(d.items())

# clear
# d.clear()
# print(d)

# get
print("-" * 20)
#print(d["favorite_food"])
print(d.get("favorite_food"))


print("{:=^20}".format("집합 자료형"))
lst = [1, 2, 3, 4, 1, 2, 3, 4, 6, 5, 7, 7]
print(list(set(lst)))

t = (1, 2, 3, 4, 5, 6)
t = tuple(list(t) + [7])
print(t)

print(list("ABCDEFG"))
print("\n" * 3)






