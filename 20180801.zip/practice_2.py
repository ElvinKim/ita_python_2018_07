i = 0
while i < 10:
    print("*", end="")
    i += 1
print("")

x = 0

while x ** 3 <= 10000:
    x += 1

print(x)
