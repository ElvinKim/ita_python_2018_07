import random

# sol 1
lotto_num_lst = []

while len(lotto_num_lst) < 6:
    random_num = random.randint(1, 45)

    if random_num not in lotto_num_lst:
        lotto_num_lst.append(random_num)

print(lotto_num_lst)

# sol 2
lotto_num_lst = random.sample(range(1, 46), 6)
print(lotto_num_lst)

# sol 3
lotto_num_range = [i for i in range(1, 46)]
lotto_num_lst = []
for x in range(6):
    random_index = random.randint(0, 44 - x)
    lotto_num_lst.append(lotto_num_range.pop(random_index))

print(lotto_num_lst)






