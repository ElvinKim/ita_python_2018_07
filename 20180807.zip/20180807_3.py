"""
ITA Python - 파일
"""
# print("{:=^20}".format("파일 쓰기"))
# f = open("test.txt", "w")
# f.write("TEST2")
# f.close()

print("{:=^20}".format("파일 읽기"))
f = open("test.txt", "r")

# print(f.readline())
print(f.readline())
print(f.readline())
print("-" * 20)

for line in f.readlines():
    print(line)

print("-" * 20)
print(f.read())
f.close()


