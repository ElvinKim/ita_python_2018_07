# while True:
#     try:
#         a = int(input("a= "))
#         b = int(input("b= "))
#         print(a / b)
#     except ZeroDivisionError as e:
#         print(e)
#         print("0으로 나누지마!!!!!")
#     except ValueError:
#         print("문자열은 숫자로 못바꾼다!!!!")

#
# while True:
#     try:
#         a = int(input("a= "))
#         b = int(input("b= "))
#         print(a / b)
#     except Exception as e:
#         print(e)

class Person:
    def introduce(self):
        raise NotImplemented


class Student(Person):
    def introduce(self):
        print("나는 학생입니다.")


lee = Student()
lee.introduce()


class ScoreError(Exception):
    def __str__(self):
        return "0보다 작거나 100보다 큰 수는 넣을 수 없습니다."


def input_score(score):
    if score < 0 or score > 100:
        raise ScoreError
    print("Score: ", score)

try:
    input_score(1000)
except Exception as e:
    print(e)
