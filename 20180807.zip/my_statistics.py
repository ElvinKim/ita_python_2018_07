def add(a, b):
    return a + b


def sub(a, b):
    return a - b


def sample():
    return 10


print("my_statistics", __name__)

if __name__ == "__main__":
    print(add(10, 20))
    print(sub(20, 10))
