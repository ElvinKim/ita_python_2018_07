def print_module3():
    print("Module 3")