def print_module4():
    print("Module 4")
