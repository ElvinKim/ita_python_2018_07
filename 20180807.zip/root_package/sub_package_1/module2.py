def print_module2():
    print("Module 2")
