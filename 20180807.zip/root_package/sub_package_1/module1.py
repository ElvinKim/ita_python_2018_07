def print_module1():
    print("Module 1")