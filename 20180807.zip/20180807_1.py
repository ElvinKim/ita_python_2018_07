print("{:=^20}".format("모듈"))

import sys
sys.path.append("C:\\Users\\user\\Desktop\\a")
print(sys.path)
import random
import aaa
# sys.exit()

print(aaa.sample())


print("test")
