import my_statistics

print("my_main_2", __name__)