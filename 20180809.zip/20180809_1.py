import urllib.request
import re

fp = urllib.request.urlopen("http://www.naver.com")
mybytes = fp.read()

mystr = mybytes.decode("utf8")
fp.close()


pattern = re.compile('<span class="ah_k">(.*?)</span>', re.DOTALL)

print(pattern.findall(mystr))
