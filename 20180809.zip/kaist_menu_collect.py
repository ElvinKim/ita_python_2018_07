import urllib.request
import re


url = "https://www.kaist.ac.kr/_prog/fodlst/index.php?site_dvs_cd=kr&menu_dvs_cd=050303&dvs_cd=east1&stt_dt=2018-08-10&site_dvs="
fp = urllib.request.urlopen(url)
mybytes = fp.read()

mystr = mybytes.decode("utf8")
fp.close()

menu_pattern = re.compile('''<table class="menuTb".*?<td.*?>(.*?)</td>.*?<td.*?>(.*?)</td>.*?<td.*?>(.*?)</td>''', re.DOTALL)

print(menu_pattern.findall(mystr))
print("=" * 20)

for menu in menu_pattern.findall(mystr)[0]:
	print(menu.replace("<br />", "")
		.replace("&amp;", "")
		.replace("&lt;", "<")
		.replace("&gt;", ">")
		.replace("&quot;", '"'), end="")
	print("-" * 20)