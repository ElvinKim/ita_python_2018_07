import urllib.request
from bs4 import BeautifulSoup

fp = urllib.request.urlopen("http://www.naver.com")
mybytes = fp.read()

mystr = mybytes.decode("utf8")
fp.close()

soup = BeautifulSoup(mystr, "html.parser")
result = soup.find_all("span", {"class": "ah_k"})

for word in result:
    print(word.text)
