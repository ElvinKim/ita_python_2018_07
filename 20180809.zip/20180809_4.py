import urllib.request
from bs4 import BeautifulSoup


url = "https://www.kaist.ac.kr/_prog/fodlst/index.php?site_dvs_cd=kr&menu_dvs_cd=050303&dvs_cd=east1&stt_dt=2018-08-10&site_dvs="
fp = urllib.request.urlopen(url)
mybytes = fp.read()

mystr = mybytes.decode("utf8")
fp.close()

soup = BeautifulSoup(mystr, "html.parser")

menu_list = soup.find("table", {"class": "menuTb"}).find_all("td")

for menu in menu_list:
    print(menu.text)
    print("-" * 20)













