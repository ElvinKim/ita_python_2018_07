# problem 1
a = 20180108

year = int(a / 10000)
month = int((a % 10000) / 100)
day = a % 100

print("{:04d}.{:02d}.{:02d}".format(year, month, day))

# problem 2
a = str(a)
year = a[0:4]
month = a[4:6]
day = a[6:]

print("%s년 %s월 %s일" % (year, month, day))

# problem 3
b = "hi sangmook"
print("hello" + b[2:])
