print("{:=^20}".format("문자열 함수"))

# count
print("ABCAABCCCE".count("A"))
print("ABCAABCCCE".count("ABC"))

# find, index
print("-" * 20)
a = "ABCABCABC"
print(a.index("B"))
print(a.find("B"))

#print(a.index("D"))
print(a.find("D"))

# join
print("-" * 20)
print(",".join("ABC"))

# upper & lower
print("-" * 20)

print("Python Is Very GooD!!!".upper())
print("Python Is Very GooD!!!".lower())


# strip
print("-" * 20)
print("          a b c          ")
print("          a b c          ".lstrip())
print("          a b c          ".rstrip())
print("          a b c          ".strip())

# replace
print("-" * 20)
print("hi hi sangmook".replace("hi", "hello"))

# split
print("-" * 20)
print("hi~ python is very good. go for it!!".split())


# d = "."
# line = "hi sangmook. good. wow."
# s =  [e+d for e in line.split(d) if e]
# print(s)

# print("-" * 20)
# a = "java is very good"
# print(a.replace("java", "python").replace("good", "perfect").split())
