# problem 1
a = input("insert your string : ")
print(a[0].upper() + a[1:-1].lower() + a[-1].upper())

a = input("insert your number : ")
print(int(a) + 10)

a = input("insert your strings : ")
print(a.split())

