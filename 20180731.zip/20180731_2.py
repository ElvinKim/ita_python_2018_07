"""
ITA Python - 자료형(2)
"""
print("{:=^20}".format("리스트"))

# List
print([1, 2, 3, 4])

# 인덱싱 & 슬라이싱
a = ["python", 2, 3, 4, 5]
print(a[0])
print(a[0].upper())
print(a[1] + a[2])
print(a[0][0])
	
print(a[1:2])
print(a[1])


# 리스트 연산자
print("-" * 20)
print([1, 2, 3] + [4, 5, 6])
print([1, 2, 3] * 3)

# 리스트 수정 & 삭제
print("-" * 20)
a = [1, 2, 3, 4, 5]
a[0] = 100
a[-1] = 700
a[1:-1] = [200, 300, 400, 500, 600]
# a[1] = [200, 300, 400, 500, 600]
print(a)
# del a[1]
del a[2:5] # a[2:5] = []
print(a)


# 리스트 관련 함수
# append
print("-" * 20)
a = [1, 2, 3, 4]
a.append(5)
print(a)

# sort
a = [4, 3, 1, 2, 4, 6]
a.sort()
print(a)
a.sort(reverse=True)
print(a)

b = "abc"
print(b.replace("c", "D"))
print(b)

# reverse
print("-" * 20)
a = [1, 3, 5, 6]
a.reverse()
print(a)

# index
print("-" * 20)
a = [1, 2, 3, 1, 2, 3]
b = ["A", "B", "C", "B"]
print(a.index(2))
print(b)
print(b.index("B"))

# insert
print("-" * 20)
a = ["A", "B", "D", "E"]
a.insert(2, "C")
print(a)

# remove
print("-" * 20)
a = ["A", "B", "D", "E", "A", "B"]
a.remove("A")
print(a)

# pop
print("-" * 20)
lst = [1, 2, 3, 4, 5, 6, 7]
print(lst.pop())
print(lst.pop(0))
print(lst)

# count
print("-" * 20)
lst = [1, 2, 3, 4, 1, 2, 3]
print(lst.count(3))


# extend
lst1 = [1, 2, 3]
lst2 = [4, 5, 6]

lst1.extend(lst2) #lst1 = lst1 + lst2  => lst1 += lst2
print(lst1)

print("{:=^20}".format("튜플"))
t = (1, 2, 3, 4, 5)
x, y, z = (10, 20, 30)
print(x)
print(y)
print(z)
