# from my_statistics import *
import my_statistics

def sample():
    return 20

# print(my_statistics.add(10, 20))
# print(add(10, 20))
print(my_statistics.sample())
print(sample())
