class Vector2D:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get(self):
        return self.x, self.y

    def __str__(self):
        return "<{}, {}>".format(self.x , self.y)

    def __eq__(self, other):
        return (self.x, self.y) == (other.x, other.y)


v1 = Vector2D(1, 2)
v2 = Vector2D(2, 4)
v3 = Vector2D(1, 2)


print(v1)  # <1, 2>
print(v1 == v3)

