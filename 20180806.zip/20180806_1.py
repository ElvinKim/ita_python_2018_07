class Student:
	student_id = 1000
	major = "math"
	grade = 4
	name = "영희"
	gender = "여"


	def study(self, subject):
		print(self.name + "이/가" + subject + "를 공부합니다.")


	def eat(self, food):
		print(self.name + "이/가" + food + "를 먹습니다.")


class Country:
	name = "Korea"
	language = "Korean"
	capital = "Seoul"
	populatioin = 50000000


	def collect_tax(self, person, price):
		print(self.name + "에서" + person + "에게" + price + "만큼 세금을 걷습니다.")


class Knight:
	level = 20
	name = "만년동 핵폭탄"
	hp = 200


	def move(self, direction):
		print(direction + " 방향으로 이동합니다")


	def attack(self):
		print(self.name + "이 공격합니다")

	def print_id(self):
		print(id(self))

knight1 = Knight()
print(knight1.level, knight1.name, knight1.hp)
knight1.attack()
knight1.move("앞")

print(id(knight1))
knight1.print_id()

knight2 = Knight()
print(id(knight2))
knight2.print_id()

knight2.level = 200
knight2.name = "자다깬 용사"
knight2.hp = 2000

print("-" * 20)
print(knight2.level)
print(knight2.name)
print(knight2.hp)

print("-" * 20)
print(Knight.__dict__)
print(knight1.__dict__)
print(knight1.level)
print("-" * 20)
knight1.level = 30
print(Knight.__dict__)
print(knight1.__dict__)
print(knight1.level)


class Knight:

	def __init__(self, l, n, h):
		self.level = l
		self.name = n
		self.hp = h

	def move(self, direction):
		print(direction + " 방향으로 이동합니다")


	def attack(self):
		print(self.name + "이 공격합니다")


	def print_id(self):
		print(id(self))


	def set_level(self, lv):
		if lv > 999:
			self.level = 999
		else:
			self.level = lv

	def get_level(self):
		return self.level

	def set_name(self, name):
		self.name = name


knight3 = Knight(20, "한방이야", 4000)

print("-" * 20)
print(Knight.__dict__)
print(knight3.__dict__)


print("-" * 20)
print(knight3.level)
knight3.level = 200
knight3.set_level(300)
print(knight3.get_level())

knight3.set_level(10000000)
print(knight3.get_level())





class Person:
	def __init__(self, name):
		self.name = name

	def use(self, machine):
		print(self.name + "이/가", machine.name + "을 사용합니다.")


class Machine:
	def __init__(self, name):
		self.name = name


a = Person("영희")
smart_phone = Machine("iphone X")

a.use(smart_phone)




